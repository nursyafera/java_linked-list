
/**
 * Write a description of class Book here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.*;

public class Book
{
    //Class should be able to display title, year published, price and author of each book
    String title, author;
    int year;
    double price;
    
    //constructor
    public Book()
    {
        title = null;
        author = null;
        year = 0;
        price = 0;
    }
    
    //constructor with parameter
    public Book(String t, String a, int y, double p)
    {
        title = t;
        author = a;
        year = y;
        price = p;
    }
    
    //Method to return title, year published, price and author's name
    public String toString()
    {
        return
        "Book Title : " + title +
        "\nYear Published : " + year +
        "\nPrice : RM " + price +
        "\nAuthor : " + author +
        "\n";
    }
    
    //Set title, year published, price and author's name
    public void setData(String t, String a, int y, double p)
    {
        title = t;
        author = a;
        year = y;
        price = p;
    }
    
    //Method to return title
    public String getTitle() { return title; }
    
    //Method to return year published
    public int getYear() { return year; }
    
    //Method to return price
    public double getPrice() { return price; }
    
    //Method to return author's name
    public String getAuthor() { return author; }
}

