
/**
 * Write a description of class AppQueueBook here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner; //To use Scanner function

public class AppQueueBook
{
    public static void main (String []args)
    {
        //Declaring Queue Object
        MyQUEUE BookQ = new MyQUEUE(); //Main Queue Object | A. Declare a queue of books object named BookQ
        MyQUEUE temp = new MyQUEUE(); //Temporary Queue Object
    
        //Declaring Scanner Object
        Scanner scan = new Scanner(System.in);
    
        //Declaring variable
        String title, author;
        double price;
        int year;
    
        System.out.println("-Please Enter 10 Books- \n");
    
        //B. ask user to enter 10 Book objects into queue BookQ
        for(int i=0; i<10; i++)
        {
            System.out.print("Enter Book's Title : ");
            title = scan.next();
        
            System.out.print("Enter Book's Year of Published : ");
            year = scan.nextInt();
        
            System.out.print("Enter Book's Price : ");
            price = scan.nextDouble();
        
            System.out.print("Enter Book's Author : ");
            author = scan.next();
            
            //Input data into Book Object
            Book book1 = new Book(title, author, year, price);
            
            //Input data into Main Queue Object
            BookQ.enqueue(book1);
            
            if(i<9)
                System.out.println("\n-Please Enter Next Book-\n");
        }
        
        System.out.println(" ");
        
        //C. Display all books details in BookQ
        System.out.println("-List of Books-\n");
        Book book2;
        while(!BookQ.isEmpty())
        {
            book2 = (Book) BookQ.dequeue();
            System.out.println(book2);
            
            temp.enqueue(book2);
        }
        
        while(!temp.isEmpty())
            BookQ.enqueue(temp.dequeue());
        
        //D. Display all books which were published before year 2000.
        Book book3;
        System.out.println("-Book Published before year 2000-\n");
        while(!BookQ.isEmpty())
        {
            book3 = (Book) BookQ.dequeue();
                        
            if(book3.getYear() < 2000)
                System.out.println(book3);
            
            temp.enqueue(book3);
        }
        
        while(!temp.isEmpty())
            BookQ.enqueue(temp.dequeue());
        
        //E. Search and display a book with the lowest price.    
        Book book4;
        System.out.println("-Book with lowest price-\n");
        double lowest = 999999999;
        while(!BookQ.isEmpty())
        {
            book4 = (Book) BookQ.dequeue();
                        
            if(book4.getPrice() < lowest)
                lowest = book4.getPrice();
            
            temp.enqueue(book4);
        }
        
        while(!temp.isEmpty())
        {
            book4 = (Book) temp.dequeue();
            
            if(book4.getPrice() == lowest)
                System.out.println(book4);
            
            BookQ.enqueue(book4);
        }
        
        //F. Declare another queue of books object named BookQOld, all books published before year 2000 should be copied into this queue
        Book book5;
        MyQUEUE BookQOld = new MyQUEUE();
        while(!BookQ.isEmpty())
        {
            book5 = (Book) BookQ.dequeue();
                        
            if(book5.getYear() < 2000)
                BookQOld.enqueue(book5);
        }
    }
}
