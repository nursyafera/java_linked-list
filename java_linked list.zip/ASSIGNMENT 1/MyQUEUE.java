
/**
 * Write a description of class MyQUEUE here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MyQUEUE extends LinkedList
{
    //Insert data into Queue
    public void enqueue(Object elem)
    {
        insertAtBack(elem);
    }
    
    //Remove data from Queue
    public Object dequeue()
    {
        return removeFromFront();
    }
}
