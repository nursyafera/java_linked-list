
/**
 * Write a description of class MyStack here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class MyStack extends LinkedList
{
    //Insert data into Stack
    public void push(Object elem)
    {
        insertAtBack(elem);
    }
    
    //Insert data from Stack
    public Object pop()
    {
        return removeFromBack();
    }
    
    //Check if stack is empty
    public boolean Empty()
    {
        return isEmpty();
    }
}
