
/**
 * Write a description of class AppStack here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner; //To use Scanner function

public class AppStack
{
    public static void main(String []args)
    {
        //Declaring Stack Object
        MyStack stack = new MyStack();
        
        //Declaring Scanner Object
        Scanner scan = new Scanner(System.in);
        
        //Get Input
        System.out.print("Enter Postfix Expressions : ");
        String input = scan.next();
        
        //Insert data into Stack
        for(int i=0; i<input.length() ; i++)
        {
            Object data = (Object) input.charAt(i); //Parse characters from String into Object
            stack.push(data);
        }
        
        //Seperate Operand and Operator
        int operand1=0, operand2=0; //Declaring and initialize Operand
        char operator=' '; //Declaring and initialize Operatlor
        while(!stack.Empty())
        {
            char c = (char) stack.pop();
            
            if(Character.isDigit(c))
            {
                if(operand1 == 0)
                    operand1 = Character.getNumericValue(c);
                else
                    operand2 = Character.getNumericValue(c);
            }
            else
                operator = c;
        }
        
        //Set result base on operator
        int result = 0;
        switch(operator)
        {
            case '+':
            result = operand1 + operand2;
            break;
                     
            case '-':
            result = operand1 - operand2;
            break;
                     
            case '/':
            result = operand1 / operand2;
            break;
                     
            case '*':
            result = operand1 * operand2;
            break;
        }
        
        System.out.print("Result : " + result);
    }
}
